#include "scene.h"

#include "renderer.h"
#include "inputsystem.h"

#include <cassert>


Scene::Scene()
{
}

Scene::~Scene()
{
}

bool Scene::Initialise(Renderer& renderer)
{
	return true;
}